# HTML5_CSS3_JavaScript
Curso em Vídeo - HTML5 + CSS3 + JS

Repositório em branco, usado nas aulas do Guanabara do Curso de HTML + CSS + JavaScript.


# CLIQUE AQUI PARA BAIXAR O ARQUIVO .ZIP:
[Curso HTML5 Pacote01.zip](https://github.com/heloisaldanha/HTML5_CSS3_JavaScript/blob/master/curso-html5-pacote01.zip)

# OBS.:
Adicionar esses dois vídeos ao arquivo de media:
[Link](https://github.com/Victor-Eduardo-art/google-glass/tree/master/projeto-glass-html5/_media)

